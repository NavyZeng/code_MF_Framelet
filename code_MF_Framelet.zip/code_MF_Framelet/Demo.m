% This script run the MF_Framelet based completion method
% More detail can be found in [1]
% [1] Tai-Xiang Jiang, Ting-Zhu Huang, Xi-Le Zhao, Teng-Yu Ji, and Liang-Jiang Deng
%     Matrix factorization for low-rank tensor completion using framelet prior
%
% created by Tai-Xiang Jiang
% 7/19/2018
clc,clear,close all
addpath(genpath('./lib'))
addpath('./data')

for tensor_num=2
    
    switch tensor_num
        case 1
            load suzie.mat
        case 2
            load hall.mat       
    end
%%
sr=0.2;
if max(X(:))>1
X=X/max(X(:));
end
%%
Nway=[size(X,1), size(X,2), size(X,3)];
n1 = size(X,1); n2 = size(X,2); 
frames=size(X,3);
ratio = 0.005;
R=AdapN_Rank(X,ratio);
Y_tensorT = X;
%% 
p = round(sr*prod(Nway));
known = randsample(prod(Nway),p); data = Y_tensorT(known);
[known, id]= sort(known); data= data(id);
Y_tensor0= zeros(Nway); Y_tensor0(known)= data;
imname=[num2str(tensor_num),'_tensor0'];

%% get the initialization X and A
for n = 1:3
    coNway(n) = prod(Nway)/Nway(n);
end
for i = 1:3
    Y0{i} = Unfold(Y_tensor0,Nway,i);
    Y0{i} = Y0{i}';
    X0{i}= rand(coNway(i), R(i));
    A0{i}= rand(R(i),Nway(i));
end
    save(imname,'Y_tensor0','Y_tensorT','known','A0','Y0','X0','Nway');
    
%% 
opts=[];
opts.maxit=2000;
opts.Ytr= Y_tensorT;
opts.tol=1e-4;
alpha=[1,1,1];
opts.alpha = alpha / sum(alpha);
rho=0.1;        
%%  MF_Framelet
        opts2=[];
        opts.rho1=rho;
        opts2.mu=10;
        opts2.beta=1000;
        opts2.F_tol=1e-6;
        opts2.frame=1;
        opts2.Level=1;  
        opts2.wLevel=1/2;
        opts2.x_size=Nway(1:2);
        opts2.F_it=10;
        fprintf('\n');
        disp('Begin the MF_Framelet')
        tic
        fprintf('\n');
        [Y_tensor_F, A_F, X_F, Out_F]= LRTC_F_X3(Y0, data, A0, X0,Y_tensor0, Nway, known, opts,opts2);
        time_F = toc;
        psnr_one=PSNR(Y_tensor_F, Y_tensorT);
        imname=[num2str(tensor_num),'_result_FX3_psnr_',num2str(psnr_one),'_mu',num2str(opts2.mu),'beta_',num2str(opts2.beta),'Initer_',num2str(opts2.F_it),'.mat'];
        save(imname,'A_F','X_F','Y_tensor_F','opts2','Out_F');
end
